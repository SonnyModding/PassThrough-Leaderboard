﻿namespace SonnyMods
{
	/// <summary>
	/// This class is used to provide information about your mod to BepInEx.
	/// </summary>
	class PluginInfo
	{
		public const string GUID = "com.Sonny.gorillatag.InvisLeaderboard(:";
		public const string Name = "Passthrough leaderboard";
		public const string Version = "1.0.0";
	}
}
