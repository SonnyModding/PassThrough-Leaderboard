﻿using System;

namespace SonnyMods
{
    public class Class1
    {
    }
}
